/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Truck, 
  Home, 
  Building2, 
  Package, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  Globe2,
  Heart,
  Phone, 
  Mail, 
  ChevronRight, 
  Star,
  Menu,
  X,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  TrendingDown,
  AlertCircle,
  Wrench,
  Monitor,
  Users,
  Archive,
  Facebook,
  MessageCircle,
  Youtube,
  ExternalLink,
  Plus,
  Minus,
  Quote,
  PhoneCall,
  Music,
  Bike,
  GraduationCap,
  Briefcase,
  Box,
  Play,
  UserCheck,
  CreditCard,
  Banknote,
  Sofa,
  Armchair,
  Table,
  Bed,
  Utensils,
  Waves,
  Snowflake,
  Library,
  Maximize,
  Layers,
  Flame,
  Lightbulb,
  Leaf
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GoogleMap, 
  LoadScript, 
  DirectionsService, 
  DirectionsRenderer 
} from '@react-google-maps/api';

const Navbar = ({ onNavigate }: { onNavigate: (v: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="relative w-12 h-12 flex items-center justify-center">
              <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
              <Truck className="text-primary w-8 h-8 relative z-10" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                POMT <span className="text-accent">Logistics</span> LTD
              </span>
              <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-sm font-medium text-slate-600 hover:text-primary transition-colors">Services</a>
            <a href="#how-it-works" className="text-sm font-medium text-slate-600 hover:text-primary transition-colors">How it Works</a>
            <a href="#about" className="text-sm font-medium text-slate-600 hover:text-primary transition-colors">About Us</a>
            <a href="#contact" className="text-sm font-medium text-slate-600 hover:text-primary transition-colors">Contact</a>
            <button 
              onClick={() => onNavigate('inventory-calculator')}
              className="bg-primary text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-primary-light transition-all shadow-lg shadow-primary/20"
            >
              Get a Quote
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-slate-600">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-white border-b border-slate-200 px-4 py-6 flex flex-col gap-4"
          >
            <a href="#services" onClick={() => setIsOpen(false)} className="text-lg font-medium text-slate-600">Services</a>
            <a href="#how-it-works" onClick={() => setIsOpen(false)} className="text-lg font-medium text-slate-600">How it Works</a>
            <a href="#about" onClick={() => setIsOpen(false)} className="text-lg font-medium text-slate-600">About Us</a>
            <a href="#contact" onClick={() => setIsOpen(false)} className="text-lg font-medium text-slate-600">Contact</a>
            <button 
              onClick={() => { setIsOpen(false); onNavigate('inventory-calculator'); }}
              className="bg-primary text-white px-6 py-3 rounded-xl font-semibold"
            >
              Get a Quote
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = ({ onNavigate }: { onNavigate: (v: string) => void }) => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        {/* Map Background Image */}
        <div 
          className="absolute inset-0 opacity-[0.15] grayscale"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1569336415962-a4bd9f6dfc0f?auto=format&fit=crop&q=80&w=2000")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 rounded-bl-[100px]" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider mb-6">
              <ShieldCheck className="w-4 h-4" />
              Fully Insured & Professional
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold leading-[1.1] mb-6 text-slate-900">
              Moving Made <span className="text-primary">Simple</span> & Stress-Free
            </h1>
            <p className="text-lg text-slate-600 mb-8 max-w-lg leading-relaxed">
              POMT LOGISTICS LTD provides reliable house, office removal and storage services across the UK and Europe. Professional service starting <strong>from £26</strong>.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onNavigate('inventory-calculator')}
                className="bg-primary text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-primary-light transition-all flex items-center gap-2 group shadow-xl shadow-primary/30"
              >
                Get Instant Quote
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <a 
                href="https://wa.me/447449970756"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-50 transition-all flex items-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-5 h-5 text-[#25D366]" />
                WhatsApp
              </a>
            </div>

            <div className="mt-10 flex items-center gap-6">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <img 
                    key={i}
                    src={`https://picsum.photos/seed/user${i}/100/100`} 
                    alt="User" 
                    className="w-10 h-10 rounded-full border-2 border-white object-cover"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-sm text-slate-500 font-medium">Trusted by 2,000+ happy customers</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_2.png" 
                alt="POMT Logistics Removal Van" 
                className="w-full h-auto"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </div>
            
            {/* Floating Card */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl z-20 max-w-[240px]"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <CheckCircle2 className="text-green-600 w-5 h-5" />
                </div>
                <span className="font-bold text-slate-800">Fast Booking</span>
              </div>
              <p className="text-sm text-slate-500">Book your move in less than 2 minutes with our instant system.</p>
            </motion.div>

            {/* Decorative Elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 rounded-full -z-10 blur-2xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Services = ({ onNavigate }: { onNavigate: (v: string) => void }) => {
  const services = [
    {
      title: "House Removals",
      description: "Complete home moving services, from packing to unloading at your new destination.",
      icon: <Home className="w-8 h-8" />,
      color: "bg-blue-50 text-blue-600",
      price: "£35"
    },
    {
      title: "Office Removals",
      description: "Efficient business relocation with minimal downtime for your operations.",
      icon: <Building2 className="w-8 h-8" />,
      color: "bg-purple-50 text-purple-600",
      price: "£150"
    },
    {
      title: "Man & Van",
      description: "Perfect for smaller moves, single items, or student relocations.",
      icon: <Truck className="w-8 h-8" />,
      color: "bg-orange-50 text-orange-600",
      price: "£35"
    },
    {
      title: "Packing Services",
      description: "Professional packing using high-quality materials to keep your items safe.",
      icon: <Package className="w-8 h-8" />,
      color: "bg-green-50 text-green-600",
      price: "£150"
    },
    {
      title: "Piano Transport",
      description: "Specialized handling for delicate and heavy musical instruments.",
      icon: <Music className="w-8 h-8" />,
      color: "bg-indigo-50 text-indigo-600",
      price: "£120"
    },
    {
      title: "International Removals",
      description: "Moving across Europe or internal UK? We handle cross-border logistics with ease.",
      icon: <Globe2 className="w-8 h-8" />,
      color: "bg-blue-50 text-blue-600",
      price: "£250"
    },
    {
      title: "Student Removals",
      description: "Affordable and flexible moves for university students.",
      icon: <GraduationCap className="w-8 h-8" />,
      color: "bg-cyan-50 text-cyan-600",
      price: "£26"
    },
    {
      title: "Storage Services",
      description: "Safe and secure short or long-term storage solutions.",
      icon: <Box className="w-8 h-8" />,
      color: "bg-slate-50 text-slate-600",
      price: "£24"
    }
  ];

  return (
    <section id="services" className="relative py-24 bg-white overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div 
          className="absolute inset-0 opacity-[0.05] grayscale"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1569336415962-a4bd9f6dfc0f?auto=format&fit=crop&q=80&w=2000")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-primary uppercase tracking-widest mb-3">Our Services</h2>
          <p className="text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Tailored Solutions for Every Move</p>
          <p className="text-slate-500 max-w-2xl mx-auto">We offer a wide range of logistics and removal services designed to meet your specific needs and budget.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -10 }}
              className="p-8 rounded-3xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:shadow-xl transition-all"
            >
              <div className={`${service.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6`}>
                {service.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-900">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed mb-4">{service.description}</p>
              <p className="text-primary font-bold mb-6">Starting from {service.price}</p>
              <button 
                onClick={() => {
                  if (service.title === "House Removals") onNavigate('house-pricing');
                  if (service.title === "Office Removals") onNavigate('office-pricing');
                  if (service.title === "Man & Van") onNavigate('man-van-pricing');
                  if (service.title === "Packing Services") onNavigate('packing-pricing');
                  if (service.title === "Piano Transport") onNavigate('piano-pricing');
                  if (service.title === "Motorcycle Transport") onNavigate('motorcycle-pricing');
                  if (service.title === "Student Removals") onNavigate('student-pricing');
                  if (service.title === "Storage Services") onNavigate('storage-pricing');
                }}
                className="inline-flex items-center gap-2 text-primary font-bold group"
              >
                Learn More
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const HowItWorks = ({ onNavigate }: { onNavigate: (v: string) => void }) => {
  const steps = [
    {
      title: "House & Office Removals",
      description: "From single rooms to entire office buildings, we handle every move with precision.",
      icon: "01"
    },
    {
      title: "Secure Storage Solutions",
      description: "Safe, climate-controlled storage for your belongings during transitions.",
      icon: "02"
    },
    {
      title: "We Handle the Rest",
      description: "Our professional team arrives and handles the heavy lifting safely.",
      icon: "03"
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-sm font-bold text-primary-light uppercase tracking-widest mb-3">Process</h2>
            <p className="text-4xl lg:text-5xl font-bold mb-8">How POMT Logistics Works</p>
            
            <div className="space-y-12">
              {steps.map((step, idx) => (
                <div key={idx} className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full border border-white/20 flex items-center justify-center font-display font-bold text-primary-light">
                    {step.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                    <p className="text-slate-400 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <button 
              onClick={() => onNavigate('inventory-calculator')}
              className="mt-12 bg-white text-slate-900 px-8 py-4 rounded-full font-bold hover:bg-slate-100 transition-all"
            >
              Start Your Quote Now
            </button>
          </div>

          <div className="relative">
            <div className="rounded-3xl overflow-hidden border-8 border-white/5 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&q=80&w=1000" 
                alt="Modern Warehouse Storage" 
                className="w-full h-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-primary p-8 rounded-3xl shadow-2xl hidden md:block">
              <div className="text-4xl font-bold mb-1">99%</div>
              <div className="text-sm font-medium text-white/80 uppercase tracking-wider">Customer Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const reviews = [
    {
      name: "Sarah Jenkins",
      role: "Home Owner",
      content: "POMT Logistics made our house move so easy. The team was professional, careful with our furniture, and very efficient. Highly recommend!",
      image: "https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_1.png"
    },
    {
      name: "The Thompson Family",
      role: "Family Move",
      content: "Relocating with a child is stressful, but the team at POMT was amazing. They were patient, careful, and even made the process fun for our little one.",
      image: "https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_0.png"
    },
    {
      name: "David Wilson",
      role: "Student",
      content: "Great service for a small move. The driver was helpful and the price was much better than other quotes I received.",
      image: "https://picsum.photos/seed/david/100/100"
    }
  ];

  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-primary uppercase tracking-widest mb-3">Testimonials</h2>
          <p className="text-4xl font-bold text-slate-900">What Our Clients Say</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, idx) => (
            <div key={idx} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
              <div className="flex items-center gap-1 mb-6">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-slate-600 italic mb-8 leading-relaxed">"{review.content}"</p>
              <div className="flex items-center gap-4">
                <img 
                  src={review.image} 
                  alt={review.name} 
                  className="w-12 h-12 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-bold text-slate-900">{review.name}</h4>
                  <p className="text-sm text-slate-500">{review.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const TrustedByFamilies = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm font-bold text-accent uppercase tracking-widest mb-4">Trusted by Families</h2>
            <h3 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Moving Lives, Not Just <span className="text-accent italic">Boxes</span>
            </h3>
            <p className="text-slate-600 text-lg leading-relaxed mb-8">
              Every move is a new chapter. Whether you're moving your first home, growing your family, or relocating your office, we're here to make the transition as smooth as possible. Our team treats your belongings as if they were our own.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                  <Heart className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Family-First Approach</h4>
                  <p className="text-slate-600">We understand the unique needs of moving with children and pets.</p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Fully Insured & Vetted</h4>
                  <p className="text-slate-600">Your peace of mind is our top priority with every single item.</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="space-y-4">
              <div className="aspect-[3/4] rounded-3xl overflow-hidden shadow-lg">
                <img 
                  src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_0.png" 
                  alt="Family moving with POMT" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="aspect-square rounded-3xl overflow-hidden shadow-lg relative group">
                <img 
                  src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_1.png" 
                  alt="Happy Couple Moving" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex items-end p-4">
                  <div>
                    <p className="text-xl font-bold text-white mb-0">2k+</p>
                    <p className="text-[10px] font-bold text-white/80 uppercase tracking-widest">Happy Families</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="pt-8 space-y-4">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-lg relative group">
                <img 
                  src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_2.png" 
                  alt="POMT Logistics Van" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex items-end p-4">
                  <div className="flex flex-col items-start">
                    <div className="flex -space-x-2 mb-2">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                          <img src={`https://i.pravatar.cc/100?u=${i}`} alt="User" />
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] font-bold text-white uppercase tracking-widest">Top Rated</p>
                  </div>
                </div>
              </div>
              <div className="aspect-[3/4] rounded-3xl overflow-hidden shadow-lg">
                <img 
                  src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_3.png" 
                  alt="Professional Lifting Equipment" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const ServiceAreas = () => {
  const areas = [
    { city: "London", region: "Greater London", status: "Primary Hub" },
    { city: "Manchester", region: "North West", status: "Regional Office" },
    { city: "Birmingham", region: "West Midlands", status: "Active" },
    { city: "Leeds", region: "West Yorkshire", status: "Active" },
    { city: "Glasgow", region: "Scotland", status: "Active" },
    { city: "Sheffield", region: "South Yorkshire", status: "Active" },
    { city: "Liverpool", region: "Merseyside", status: "Active" },
    { city: "Bristol", region: "South West", status: "Active" },
    { city: "Israel", region: "Middle East", status: "Active" },
  ];

  return (
    <section id="locations" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:40px_40px]" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm font-bold text-accent uppercase tracking-widest mb-4">Our Coverage</h2>
            <h3 className="text-4xl lg:text-5xl font-bold mb-8 leading-tight">
              Where We <span className="text-accent italic">Operate</span>
            </h3>
            <p className="text-slate-400 text-lg leading-relaxed mb-8">
              From the heart of London to the vibrant cities of Israel, POMT Logistics provides seamless removal and transport services across borders. Our local expertise ensures your move is handled with precision, no matter the distance.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                <Globe2 className="w-8 h-8 text-accent mb-4" />
                <h4 className="font-bold mb-2">UK & Europe</h4>
                <p className="text-sm text-slate-400">Full coverage across the UK and major European cities.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                <MapPin className="w-8 h-8 text-primary mb-4" />
                <h4 className="font-bold mb-2">Israel</h4>
                <p className="text-sm text-slate-400">Specialized logistics and removals in the Middle East.</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-white/5 border border-white/10 rounded-[40px] p-8 lg:p-12"
          >
            <div className="space-y-6">
              {areas.map((area, idx) => (
                <div key={idx} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0 group cursor-default">
                  <div>
                    <h4 className="font-bold text-lg group-hover:text-accent transition-colors">{area.city}</h4>
                    <p className="text-xs text-slate-500 uppercase tracking-wider">{area.region}</p>
                  </div>
                  <span className={`text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest ${
                    area.status === 'Primary Hub' || area.status === 'International Hub' 
                    ? 'bg-accent/20 text-accent' 
                    : 'bg-white/10 text-slate-400'
                  }`}>
                    {area.status}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
const RecentMoves = () => {
  const [selectedMove, setSelectedMove] = useState<any>(null);

  const moves = [
    { 
      type: "Furniture & Chairs", 
      from: "Croydon", 
      to: "Carshalton", 
      cost: "45", 
      saved: "25", 
      image: "https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&q=80&w=400",
      customer: "James Harrison",
      time: "14:30, 15th March 2026",
      history: "James needed to move a set of designer chairs from his old apartment to his new studio. Our team arrived 10 minutes early, carefully wrapped each piece, and completed the delivery in under an hour."
    },
    { 
      type: "Bicycle Delivery", 
      from: "Glasgow", 
      to: "Johnstone", 
      cost: "35", 
      saved: "15", 
      image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=400",
      customer: "Emma Stewart",
      time: "09:00, 18th March 2026",
      history: "Emma sold her vintage road bike and needed it delivered to the buyer. We provided a specialized bike rack for the van to ensure zero scratches during transit."
    },
    { 
      type: "Guitar 🎸 Transport", 
      from: "Earl's Court", 
      to: "Peckham", 
      cost: "25", 
      saved: "10", 
      image: "https://images.unsplash.com/photo-1550291652-6ea9114a47b1?auto=format&fit=crop&q=80&w=400",
      customer: "Liam O'Connor",
      time: "11:15, 20th March 2026",
      history: "A professional musician's guitar is their life. Liam trusted us with his rare Gibson. We used climate-controlled transport and padded cases to ensure it arrived in perfect tune."
    },
    { 
      type: "Home Removal", 
      from: "Stockport", 
      to: "Altrincham", 
      cost: "565", 
      saved: "377", 
      image: "https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_0.png",
      customer: "The Thompson Family",
      time: "08:00, 10th March 2026",
      history: "A full 3-bedroom house move. We deployed two large vans and a team of four. Everything from the grand piano to the garden tools was moved efficiently over two days."
    },
    { 
      type: "Office Relocation", 
      from: "London", 
      to: "Manchester", 
      cost: "450", 
      saved: "280", 
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400",
      customer: "TechFlow Solutions",
      time: "18:00, 12th March 2026",
      history: "Moving an entire IT department's hardware. We worked overnight to ensure the team could start work in Manchester by 9 AM the next morning without any downtime."
    },
    { 
      type: "House Removal", 
      from: "Birmingham", 
      to: "Solihull", 
      cost: "320", 
      saved: "180", 
      image: "https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_1.png",
      customer: "Sarah Jenkins",
      time: "10:00, 5th March 2026",
      history: "Sarah was moving to her first home. We helped with packing the kitchen and fragile items, making her first big move completely stress-free."
    },
    { 
      type: "Office Removal", 
      from: "Leeds", 
      to: "Sheffield", 
      cost: "580", 
      saved: "310", 
      image: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&q=80&w=400",
      customer: "Creative Hub Ltd",
      time: "09:30, 14th March 2026",
      history: "A creative agency relocation involving large desks and delicate artwork. We used custom crates for the art and ensured every workstation was set up exactly as requested."
    },
    { 
      type: "Secure Storage", 
      from: "London", 
      to: "POMT Storage", 
      cost: "45/mo", 
      saved: "20", 
      image: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&q=80&w=400",
      customer: "David Wilson",
      time: "15:45, 21st March 2026",
      history: "David needed a place for his belongings while traveling abroad. We picked up his items and placed them in our 24/7 monitored, climate-controlled facility."
    }
  ];

  return (
    <section className="relative py-24 bg-slate-50 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div 
          className="absolute inset-0 opacity-[0.03] grayscale"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1569336415962-a4bd9f6dfc0f?auto=format&fit=crop&q=80&w=2000")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-3 gap-12 items-start mb-12">
          <div className="lg:col-span-1">
            <h2 className="text-4xl font-bold text-slate-900 mb-6 leading-tight">
              Recent moves, reviews and price <span className="text-primary italic">whoo-hoos!</span>
            </h2>
            <p className="text-slate-600 mb-8 leading-relaxed">
              Moving a sofa down the road, or your whole house across the country? And want an unbeatable price? We've got a van for that.
            </p>
            <p className="text-slate-600 leading-relaxed">
              Because here at POMT Logistics, we absolutely love 5 star moves that can save you up to 40% compared to others. See what you could move, and save, with us!
            </p>
          </div>
          
          <div className="lg:col-span-2">
            <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x">
              {moves.map((move, idx) => (
                <motion.div 
                  key={idx}
                  whileHover={{ y: -5 }}
                  onClick={() => setSelectedMove(move)}
                  className="flex-shrink-0 w-72 bg-white rounded-3xl p-6 shadow-sm border border-slate-100 snap-start cursor-pointer transition-shadow hover:shadow-xl"
                >
                  <div className="relative h-40 bg-primary/5 rounded-2xl mb-6 overflow-hidden">
                    <img 
                      src={move.image} 
                      alt={move.type} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 right-4 bg-accent text-primary text-[10px] font-bold px-3 py-1 rounded-full shadow-lg">
                      saved £{move.saved}
                    </div>
                  </div>
                  <h3 className="font-bold text-lg text-slate-900 mb-4">{move.type}</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-slate-400">From:</span> <span className="font-medium">{move.from}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">To:</span> <span className="font-medium">{move.to}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Cost:</span> <span className="font-bold text-primary">£{move.cost}</span></div>
                    <div className="flex justify-between items-center pt-2">
                      <span className="text-slate-400">Mover:</span>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map(s => <Star key={s} className="w-3 h-3 fill-accent text-accent" />)}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-50 flex justify-center">
                    <span className="text-xs text-primary font-bold flex items-center gap-1">
                      View Details <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedMove && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-[32px] overflow-hidden shadow-2xl relative"
            >
              <button 
                onClick={() => setSelectedMove(null)}
                className="absolute top-6 right-6 z-10 w-10 h-10 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-slate-900 hover:bg-slate-100 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="grid md:grid-cols-2">
                <div className="h-64 md:h-full relative">
                  <img 
                    src={selectedMove.image} 
                    alt={selectedMove.type} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
                  <div className="absolute bottom-6 left-6 text-white">
                    <div className="bg-accent text-primary text-[10px] font-bold px-3 py-1 rounded-full inline-block mb-2">
                      saved £{selectedMove.saved}
                    </div>
                    <h3 className="text-2xl font-bold">{selectedMove.type}</h3>
                  </div>
                </div>

                <div className="p-8 md:p-10">
                  <div className="mb-8">
                    <h4 className="text-xs font-bold text-primary uppercase tracking-widest mb-4">Move Details</h4>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center flex-shrink-0">
                          <Users className="w-4 h-4 text-slate-400" />
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Customer</p>
                          <p className="text-slate-900 font-bold">{selectedMove.customer}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center flex-shrink-0">
                          <Clock className="w-4 h-4 text-slate-400" />
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Completed At</p>
                          <p className="text-slate-900 font-bold">{selectedMove.time}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center flex-shrink-0">
                          <MapPin className="w-4 h-4 text-slate-400" />
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Route</p>
                          <p className="text-slate-900 font-bold">{selectedMove.from} → {selectedMove.to}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-primary uppercase tracking-widest mb-4">Move History</h4>
                    <p className="text-slate-600 text-sm leading-relaxed italic">
                      "{selectedMove.history}"
                    </p>
                  </div>

                  <button 
                    onClick={() => setSelectedMove(null)}
                    className="w-full mt-10 bg-primary text-white py-4 rounded-2xl font-bold hover:bg-primary-light transition-all shadow-lg shadow-primary/20"
                  >
                    Close Details
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

const WhyChooseUs = ({ onNavigate }: { onNavigate: (v: string) => void }) => {
  const reasons = [
    {
      title: "5 star moving teams",
      description: "Our moving experts are based throughout the UK, so always understand your moving needs.",
      icon: <Star className="w-6 h-6" />
    },
    {
      title: "48 hour cancellation",
      description: "Plans can change, we get it, so you can always edit or cancel your booking up to 2 days beforehand.",
      icon: <Clock className="w-6 h-6" />
    },
    {
      title: "Peace of mind",
      description: "We include £50k fire and theft cover as standard (see our T&Cs for more info).",
      icon: <ShieldCheck className="w-6 h-6" />
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="aspect-square rounded-[40px] overflow-hidden border-[12px] border-slate-50 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1520038410233-7141be7e6f97?auto=format&fit=crop&q=80&w=1000" 
                alt="Professional Team" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-primary p-10 rounded-[32px] shadow-2xl hidden md:block max-w-[200px]">
              <p className="text-white font-bold text-lg leading-tight">Up to 40% cheaper than others</p>
            </div>
          </div>

          <div>
            <h2 className="text-4xl font-bold text-slate-900 mb-8 leading-tight">
              Need more reasons to get your move on? Here's three:
            </h2>
            <div className="space-y-10">
              {reasons.map((reason, idx) => (
                <div key={idx} className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
                    {reason.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{reason.title}</h3>
                    <p className="text-slate-600 leading-relaxed">{reason.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => onNavigate('inventory-calculator')}
              className="mt-12 bg-primary text-white px-10 py-4 rounded-full font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
            >
              Get an instant price
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -top-10 -left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
            <div className="relative">
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-bold uppercase tracking-wider mb-6">
                Our Story
              </span>
              <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-8 leading-tight">
                Making Life Easier Since <span className="text-primary italic">2026</span>
              </h2>
              <div className="space-y-6 text-slate-600 text-lg leading-relaxed">
                <p>
                  Founded in 2026, <span className="font-bold text-slate-900">POMT Logistics LTD</span> was born from a simple mission: to take the stress out of moving and make life easier for people across the UK and Europe.
                </p>
                <p>
                  We understood that moving house or office is more than just transporting boxes—it's about moving lives and businesses. Our professional teams are trained to handle every item with the utmost care, ensuring a seamless transition to your new beginning.
                </p>
                <div className="grid grid-cols-2 gap-6 pt-6">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <p className="text-3xl font-bold text-primary mb-1">100%</p>
                    <p className="text-sm font-bold text-slate-500 uppercase">Reliability</p>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <p className="text-3xl font-bold text-accent mb-1">UK & Europe</p>
                    <p className="text-sm font-bold text-slate-500 uppercase">Coverage</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="aspect-[4/5] rounded-[32px] overflow-hidden shadow-xl relative group">
                  <img 
                    src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_0.png" 
                    alt="POMT Logistics Hoist Truck" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="aspect-square rounded-[32px] overflow-hidden shadow-xl relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800&h=800" 
                    alt="Professional Equipment" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex items-end p-6">
                    <p className="text-[10px] font-bold tracking-widest text-white uppercase">Professional Equipment</p>
                  </div>
                </div>
              </div>
              <div className="pt-12 space-y-4">
                <div className="aspect-square rounded-[32px] overflow-hidden shadow-xl relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1600518464441-9154a4dea21b?auto=format&fit=crop&q=80&w=800&h=800" 
                    alt="Careful Handling" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex items-end p-6">
                    <p className="text-[10px] font-bold tracking-widest text-white uppercase">Careful Handling</p>
                  </div>
                </div>
                <div className="aspect-[4/5] rounded-[32px] overflow-hidden shadow-xl relative group">
                  <img 
                    src="https://storage.googleapis.com/static.antigravity.dev/0195d438-2321-7290-b146-51206899f81d/image_1.png" 
                    alt="POMT Logistics Moving Van" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
              </div>
            </div>

            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-[90%] bg-slate-900/90 backdrop-blur-md p-6 rounded-3xl border border-white/10 z-20 shadow-2xl">
              <p className="text-white font-medium italic text-center text-sm lg:text-base">
                "Our goal is to be the most trusted name in UK removals, one happy customer at a time."
              </p>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-accent/10 rounded-full blur-3xl" />
            <div className="absolute top-1/2 -translate-y-1/2 -right-4 w-24 h-24 bg-primary rounded-3xl rotate-12 -z-0 opacity-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: "How does POMT Logistics work?",
      a: "I founded POMT Logistics with the mission to create the world's most efficient logistics technology, which would help halve the number of wasted miles driven. We match your move with professional drivers who are already heading in your direction, saving you money and reducing carbon footprint."
    },
    {
      q: "Does POMT Logistics operate near me?",
      a: "We sure do. POMT Logistics operates across the whole of the UK and Europe, and our transport providers are based locally meaning no matter where you are, we'll have someone in your area to assist with your move."
    },
    {
      q: "How does POMT Logistics offer such low removal prices?",
      a: "Moving, especially if it's a whole house removal, is already expensive enough in my opinion. We utilize journeys that are already happening for smaller moves, so we can pass this saving on to you. For larger moves, we use our technology to cut down on inefficiencies."
    },
    {
      q: "Which transport services does POMT Logistics offer?",
      a: "We offer a range of delivery and removal services for both residential and business customers. House removals, Storage services, Man and van, Car transport, Piano transport, International removals, Student removals, Office removals, and more."
    },
    {
      q: "How do I get a van removal quote?",
      a: "Getting a quote on POMT Logistics is easy, and should take less than 2 minutes. Just enter your moving details on our website and you'll receive an instant price. You can then book online and we'll match you with an available transport provider."
    }
  ];

  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Ask the Team</h2>
            <p className="text-slate-600 mb-12">Hey there, we're the team at POMT Logistics, and below are some frequent questions customers often ask us:</p>
            
            <div className="space-y-4">
              {faqs.map((faq, idx) => (
                <div key={idx} className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                  <button 
                    onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                    className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-bold text-slate-900">{faq.q}</span>
                    {openIdx === idx ? <Minus className="w-5 h-5 text-primary" /> : <Plus className="w-5 h-5 text-slate-400" />}
                  </button>
                  <AnimatePresence>
                    {openIdx === idx && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="px-8 pb-6 text-slate-600 leading-relaxed"
                      >
                        {faq.a}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
            
            <a href="#" className="inline-block mt-8 font-bold text-primary border-b-2 border-primary/20 hover:border-primary transition-all pb-1">More FAQs</a>
          </div>

          <div className="relative hidden lg:block">
            <div className="bg-accent rounded-[40px] aspect-[4/5] overflow-hidden relative">
              <img 
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1000" 
                alt="Owner" 
                className="w-full h-full object-cover mix-blend-multiply opacity-80"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
              <div className="absolute bottom-10 left-10 text-white">
                <p className="text-2xl font-bold font-display">Professional Service</p>
                <p className="text-white/70">Guaranteed Quality</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const TrustedBrands = () => {
  const brands = [
    { name: "Santander", desc: "Delivering value. We pass FSQS banking regulations so that Santander could bank on us." },
    { name: "Vinted", desc: "Powering trends. We work with Vinted so your chic furniture items arrive stylishly on time." },
    { name: "eBay", desc: "Reliable deliveries. Helping thousands of eBay sellers get their items to buyers safely." }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-3 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-slate-900 mb-6 leading-tight">Trusted by brands you know and love</h2>
            <p className="text-slate-600 leading-relaxed">
              We're the mover of choice for some of the biggest businesses in the UK. They trust us to provide a reliable removals and delivery service to every corner of the UK, for a price their customers will be happy with.
            </p>
          </div>
          
          <div className="lg:col-span-2 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {brands.map((brand, idx) => (
              <div key={idx} className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
                <div className="h-12 flex items-center mb-6">
                  <span className="text-2xl font-bold font-display text-primary">{brand.name}</span>
                </div>
                <h4 className="font-bold text-slate-900 mb-2">{brand.name === "Santander" ? "Delivering value" : brand.name === "Vinted" ? "Powering trends" : "Reliable service"}</h4>
                <p className="text-sm text-slate-600 leading-relaxed">{brand.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Partners = () => {
  const partners = [
    { name: "Anyvan", icon: <Truck className="w-6 h-6" />, url: "https://www.anyvan.com" },
    { name: "Lime", icon: <Bike className="w-6 h-6" />, url: "https://www.li.me" },
    { name: "Pinlocal", icon: <MapPin className="w-6 h-6" />, url: "https://www.pinlocal.com" },
    { name: "Courier Exchange", icon: <Package className="w-6 h-6" />, url: "https://www.courierexchange.co.uk" },
    { name: "Cricket", icon: <Truck className="w-6 h-6" />, url: "https://cricketlogistics.com" },
    { name: "Shiftly", icon: <Truck className="w-6 h-6" />, url: "https://shiftly.com" },
    { name: "Rohati Ltd", icon: <Building2 className="w-6 h-6" />, url: "#" }
  ];

  return (
    <section className="py-16 bg-white border-y border-slate-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm font-bold text-slate-400 uppercase tracking-[0.2em] mb-12">Trusted Partner & Contractor For</p>
        <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20">
          {partners.map((partner, idx) => (
            <motion.a 
              key={idx} 
              href={partner.url}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05, opacity: 1 }}
              className="flex items-center gap-3 opacity-50 grayscale hover:grayscale-0 transition-all cursor-pointer"
            >
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center shadow-sm border border-slate-100">
                {React.cloneElement(partner.icon as React.ReactElement, { className: "w-6 h-6 text-primary" })}
              </div>
              <span className="font-display font-bold text-xl text-slate-700 whitespace-nowrap">{partner.name}</span>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
};

const Stats = () => {
  const stats = [
    { label: "Happy Customers", value: "2,000+", icon: <UserCheck className="w-6 h-6" /> },
    { label: "Successful Moves", value: "5,500+", icon: <Truck className="w-6 h-6" /> },
    { label: "Cities Covered", value: "150+", icon: <MapPin className="w-6 h-6" /> },
    { label: "Years Experience", value: "8+", icon: <Clock className="w-6 h-6" /> }
  ];

  return (
    <section className="relative py-20 bg-primary overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div 
          className="absolute inset-0 opacity-[0.05] grayscale brightness-0 invert"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1569336415962-a4bd9f6dfc0f?auto=format&fit=crop&q=80&w=2000")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="text-center text-white"
            >
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                {React.cloneElement(stat.icon as React.ReactElement, { className: "w-6 h-6" })}
              </div>
              <div className="text-4xl font-bold mb-1">{stat.value}</div>
              <div className="text-white/60 text-sm font-medium uppercase tracking-widest">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
const YouTubeShowcase = () => {
  return (
    <section className="py-24 bg-slate-900 overflow-hidden relative">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 text-red-500 text-xs font-bold uppercase tracking-wider mb-6">
              <Youtube className="w-4 h-4" />
              Official Channel
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              See Our Teams <span className="text-primary italic">In Action</span>
            </h2>
            <p className="text-slate-400 text-lg mb-8 leading-relaxed">
              We document our journey and showcase our professional moving standards on YouTube. Watch how we handle delicate items and large-scale removals.
            </p>
            <div className="space-y-4 mb-10">
              {[
                "Professional packing techniques",
                "Large scale office relocations",
                "Delicate piano transport sessions",
                "Customer success stories"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-slate-300">
                  <CheckCircle2 className="text-primary w-5 h-5" />
                  <span className="font-medium">{item}</span>
                </div>
              ))}
            </div>
            <a 
              href="https://youtube.com/@pomtpomtlogisticsltd?si=VQaxMo-5vuOTmSEz" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-red-600 text-white px-8 py-4 rounded-full font-bold hover:bg-red-700 transition-all shadow-xl shadow-red-600/20"
            >
              <Youtube className="w-6 h-6" />
              Subscribe to Channel
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative group cursor-pointer"
            onClick={() => window.open('https://youtube.com/@pomtpomtlogisticsltd?si=VQaxMo-5vuOTmSEz', '_blank')}
          >
            <div className="aspect-video rounded-[32px] overflow-hidden border-8 border-white/5 shadow-2xl relative">
              <img 
                src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&q=80&w=1000" 
                alt="British owners moving house with POMT Logistics" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/30 transition-all">
                <div className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-white fill-white ml-1" />
                </div>
              </div>
            </div>
            {/* Decorative stats */}
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl z-20 hidden md:block">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 p-2 rounded-full">
                  <UserCheck className="text-red-600 w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Subscribers</p>
                  <p className="text-xl font-bold text-slate-900">Growing Daily</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Trustpilot = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-50 rounded-[32px] p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 border border-slate-100 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#00b67a]/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2 group-hover:bg-[#00b67a]/10 transition-all duration-700" />
          
          <div className="flex flex-col items-center md:items-start relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-8 h-8 fill-[#00b67a] text-[#00b67a]" />
              <span className="text-2xl font-bold font-display">Trustpilot</span>
            </div>
            <div className="flex items-center gap-1 mb-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <motion.div 
                  key={i} 
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  className="w-8 h-8 bg-[#00b67a] flex items-center justify-center rounded-sm"
                >
                  <Star className="w-5 h-5 fill-white text-white" />
                </motion.div>
              ))}
            </div>
            <p className="text-slate-600 font-medium">Our Commitment to <span className="font-bold text-slate-900">5-Star Excellence</span></p>
          </div>
          
          <div className="hidden lg:flex gap-6 relative z-10">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 max-w-xs flex items-center gap-4 hover:shadow-md transition-shadow">
              <Quote className="w-10 h-10 text-primary/10 flex-shrink-0" />
              <p className="text-sm text-slate-600 italic">"We aim for perfection in every move. Your satisfaction is our primary goal."</p>
            </div>
          </div>

          <div className="text-center md:text-right relative z-10">
            <div className="mb-4">
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">Coming Soon</p>
              <p className="text-xs text-slate-500">Official Trustpilot profile in progress</p>
            </div>
            <button className="bg-[#00b67a] text-white px-6 py-2.5 rounded-full text-sm font-bold hover:bg-[#009e6a] transition-all shadow-lg shadow-[#00b67a]/20">
              Review Us Soon
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  const [showExtraStop, setShowExtraStop] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    email: '',
    movingFrom: '',
    movingTo: '',
    extraStop: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct WhatsApp message
    const message = `*New Quote Request from POMT Logistics Website*%0A%0A` +
      `*Full Name:* ${formData.fullName}%0A` +
      `*Phone:* ${formData.phoneNumber}%0A` +
      `*Email:* ${formData.email}%0A` +
      `*Moving From:* ${formData.movingFrom}%0A` +
      `*Moving To:* ${formData.movingTo}%0A` +
      (showExtraStop ? `*Additional Stop:* ${formData.extraStop}%0A` : '');

    const whatsappUrl = `https://wa.me/447449970756?text=${message}`;
    
    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
    
    // Show thank you message
    setIsSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="relative py-24 bg-white overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div 
          className="absolute inset-0 opacity-[0.05] grayscale"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1569336415962-a4bd9f6dfc0f?auto=format&fit=crop&q=80&w=2000")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-primary rounded-[40px] p-8 md:p-16 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          
          <div className="grid lg:grid-cols-2 gap-12 relative z-10">
            <div>
              <h2 className="text-4xl font-bold mb-6">Ready to Move?</h2>
              <p className="text-white/80 text-lg mb-10 max-w-md">
                Contact us today for a free consultation or use our online tool to get an instant quote.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-2xl">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-white/60">Call Us</p>
                    <p className="text-xl font-bold">+44 7498 486665</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-2xl">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-white/60">Email Us</p>
                    <p className="text-xl font-bold">pomtlogisticsltd@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-2xl">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-white/60">Visit Us</p>
                    <p className="text-xl font-bold">8 Baildon Street, London, SE8 4BQ</p>
                  </div>
                </div>
              </div>

              <div className="mt-10 flex gap-4">
                <a 
                  href="https://www.facebook.com/share/14YTTihBTxy/?mibextid=wwXIfr" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white/10 p-4 rounded-2xl hover:bg-white/20 transition-all"
                >
                  <Facebook className="w-6 h-6" />
                </a>
                <a 
                  href="https://wa.me/447449970756" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white/10 p-4 rounded-2xl hover:bg-white/20 transition-all"
                >
                  <MessageCircle className="w-6 h-6" />
                </a>
                <a 
                  href="https://youtube.com/@pomtpomtlogisticsltd?si=VQaxMo-5vuOTmSEz" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white/10 p-4 rounded-2xl hover:bg-white/20 transition-all"
                >
                  <Youtube className="w-6 h-6" />
                </a>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 text-slate-900 shadow-2xl">
              {isSubmitted ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="text-green-500 w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Thank You So Much!</h3>
                  <p className="text-slate-600 mb-8">Your request has been sent to our WhatsApp. We will get back to you shortly.</p>
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="text-primary font-bold hover:underline"
                  >
                    Send another request
                  </button>
                </motion.div>
              ) : (
                <form className="space-y-4" onSubmit={handleSubmit}>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold mb-2">Full Name</label>
                      <input 
                        type="text" 
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                        placeholder="John Doe" 
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold mb-2">Phone Number</label>
                      <input 
                        type="tel" 
                        name="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                        placeholder="+44 000 000 000" 
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold mb-2">Email Address</label>
                    <input 
                      type="email" 
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                      placeholder="john@example.com" 
                      required
                    />
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold mb-2">Moving From</label>
                      <input 
                        type="text" 
                        name="movingFrom"
                        value={formData.movingFrom}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                        placeholder="Postcode or Address" 
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold mb-2">Moving To</label>
                      <input 
                        type="text" 
                        name="movingTo"
                        value={formData.movingTo}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                        placeholder="Postcode or Address" 
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button 
                      type="button"
                      onClick={() => setShowExtraStop(!showExtraStop)}
                      className="flex items-center gap-2 text-primary font-bold text-sm hover:text-primary-light transition-all"
                    >
                      {showExtraStop ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                      {showExtraStop ? "Remove Additional Stop" : "Add Additional Stop / Multi-drop"}
                    </button>
                  </div>

                  <AnimatePresence>
                    {showExtraStop && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="pt-2">
                          <label className="block text-sm font-bold mb-2">Additional Stop Address (Multi-drop)</label>
                          <input 
                            type="text" 
                            name="extraStop"
                            value={formData.extraStop}
                            onChange={handleChange}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none" 
                            placeholder="Identify another address" 
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <button 
                    type="submit"
                    className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-primary-light transition-all shadow-lg shadow-primary/20 mt-4"
                  >
                    Get Free Quote
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-50 pt-20 pb-10 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary p-2 rounded-lg">
                <Truck className="text-white w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-lg leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[8px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <p className="text-slate-500 leading-relaxed mb-6">
              Professional removal and logistics services for homes and offices across the UK and Europe. Reliable, insured, and affordable.
            </p>
            <div className="flex gap-4">
              <a href="https://www.facebook.com/share/14YTTihBTxy/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="bg-slate-200 p-2 rounded-lg text-slate-600 hover:bg-primary hover:text-white transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://wa.me/447449970756" target="_blank" rel="noopener noreferrer" className="bg-slate-200 p-2 rounded-lg text-slate-600 hover:bg-green-500 hover:text-white transition-all">
                <MessageCircle className="w-5 h-5" />
              </a>
              <a href="https://youtube.com/@pomtpomtlogisticsltd?si=VQaxMo-5vuOTmSEz" target="_blank" rel="noopener noreferrer" className="bg-slate-200 p-2 rounded-lg text-slate-600 hover:bg-red-600 hover:text-white transition-all">
                <Youtube className="w-5 h-5" />
              </a>
            </div>

          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-slate-500 hover:text-primary transition-colors">Home</a></li>
              <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Services</a></li>
              <li><a href="#how-it-works" className="text-slate-500 hover:text-primary transition-colors">How it Works</a></li>
              <li><a href="#contact" className="text-slate-500 hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Services</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-slate-500 hover:text-primary transition-colors">House Removals</a></li>
              <li><a href="#" className="text-slate-500 hover:text-primary transition-colors">Office Relocation</a></li>
              <li><a href="#" className="text-slate-500 hover:text-primary transition-colors">Man & Van</a></li>
              <li><a href="#" className="text-slate-500 hover:text-primary transition-colors">Packing & Storage</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Working Hours</h4>
            <ul className="space-y-4 text-slate-500">
              <li className="flex justify-between"><span>Mon - Fri:</span> <span>8:00 - 20:00</span></li>
              <li className="flex justify-between"><span>Saturday:</span> <span>9:00 - 18:00</span></li>
              <li className="flex justify-between"><span>Sunday:</span> <span>10:00 - 16:00</span></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-slate-500 text-xs text-center md:text-left">
            <p className="font-bold text-slate-700 mb-1">POMT LOGISTICS LTD - Company number: 17011091</p>
            <p>8 Baildon Street, London, SE8 4BQ | +44 7498 486665</p>
            <p className="mt-1">© {new Date().getFullYear()} All rights reserved.</p>
          </div>
          <div className="flex gap-8 text-sm text-slate-500">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

const FloatingButtons = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <motion.a 
        href="https://wa.me/447449970756"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-8 right-8 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl flex items-center justify-center group"
      >
        <MessageCircle className="w-8 h-8" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-500 font-bold whitespace-nowrap">
          WhatsApp Us
        </span>
      </motion.a>

      <motion.button 
        onClick={() => setShowModal(true)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-8 left-8 z-50 bg-primary text-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-3 font-bold group"
      >
        <PhoneCall className="w-6 h-6" />
        <span className="hidden md:inline">Call me back</span>
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white rounded-[32px] p-8 w-full max-w-md shadow-2xl"
            >
              <button 
                onClick={() => setShowModal(false)}
                className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <PhoneCall className="text-primary w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900">Request a Callback</h3>
                <p className="text-slate-500">Enter your details and we'll call you back within 15 minutes.</p>
              </div>

              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setShowModal(false); }}>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Your Name</label>
                  <input type="text" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Phone Number</label>
                  <input type="tel" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none" placeholder="+44 000 000 000" />
                </div>
                <button className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-primary-light transition-all shadow-lg shadow-primary/20">
                  Call Me Back
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

const HousePricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              House Moving <span className="text-primary italic">Price List 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Below is the 2026 Price Guide for house moving. Please note these are "starting from" prices for local moves; the final price depends on your specific inventory and distance.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Home className="text-white w-6 h-6" />
                  </div>
                  Service Type & Starting Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Service Type</th>
                        <th className="py-4 font-bold text-slate-900">Starting Price (Est.)</th>
                        <th className="py-4 font-bold text-slate-900">Best For</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Small Item / Single Furniture</td>
                        <td className="py-4 text-primary font-bold">£35</td>
                        <td className="py-4 text-slate-600">Sofa, Fridge, or Desk only</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Part-Load / Small Van</td>
                        <td className="py-4 text-primary font-bold">£59</td>
                        <td className="py-4 text-slate-600">10-15 boxes or a student room</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">1 Bedroom Flat</td>
                        <td className="py-4 text-primary font-bold">£180</td>
                        <td className="py-4 text-slate-600">Full room contents, local move</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">2 Bedroom House</td>
                        <td className="py-4 text-primary font-bold">£350</td>
                        <td className="py-4 text-slate-600">Standard 2-bed inventory</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">3 Bedroom House</td>
                        <td className="py-4 text-primary font-bold">£650</td>
                        <td className="py-4 text-slate-600">Family home move</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">4+ Bedroom House</td>
                        <td className="py-4 text-primary font-bold">£950+</td>
                        <td className="py-4 text-slate-600">Large scale relocation</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <Plus className="text-white w-6 h-6" />
                  </div>
                  Common Service Add-ons
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Package className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Packing Service</p>
                    <p className="text-primary font-bold">Starting from £150</p>
                    <p className="text-sm text-slate-500 mt-1">Includes boxes & tape</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Wrench className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Dismantle/Reassemble</p>
                    <p className="text-primary font-bold">Starting from £40</p>
                    <p className="text-sm text-slate-500 mt-1">Per item (Beds/Wardrobes)</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Clock className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Wait-Time Fee</p>
                    <p className="text-primary font-bold">£60 per hour</p>
                    <p className="text-sm text-slate-500 mt-1">If you don't have keys yet</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <ArrowUp className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Stair Surcharge</p>
                    <p className="text-primary font-bold">£20–£40 per floor</p>
                    <p className="text-sm text-slate-500 mt-1">If no lift is available</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <TrendingDown className="text-accent w-6 h-6" />
                  How to get your exact price
                </h2>
                <p className="text-slate-300 mb-6">Since AnyVan uses dynamic pricing, the "starting from" price is for the most basic version of that move. To get your final figure:</p>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Inventory matters:</span> The price changes every time you add a box or a chair to the list.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Date matters:</span> Booking a Tuesday is usually 20% cheaper than a Friday or Saturday.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">The Price Match:</span> If you have a cheaper quote from a local "Man with a Van," AnyVan will usually match it if you show them the quote.</p>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to help you draft a specific inventory list to send to them for a firm quote?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Contact Us for a Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const OfficePricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Office Relocation <span className="text-primary italic">Price Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Office removals start from £59. Business relocations often require more specialized handling for IT equipment and furniture than residential moves.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Building2 className="text-white w-6 h-6" />
                  </div>
                  Office Size & Estimated Costs
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Office Size</th>
                        <th className="py-4 font-bold text-slate-900">Starting Price (Est.)</th>
                        <th className="py-4 font-bold text-slate-900">Includes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Small Office (1-5 Desks)</td>
                        <td className="py-4 text-primary font-bold">£150 – £350</td>
                        <td className="py-4 text-slate-600">Basic furniture & equipment</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Medium Office (10-20 Desks)</td>
                        <td className="py-4 text-primary font-bold">£500 – £1,200</td>
                        <td className="py-4 text-slate-600">Full office setup, local move</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Large Office (50+ Desks)</td>
                        <td className="py-4 text-primary font-bold">£2,500+</td>
                        <td className="py-4 text-slate-600">Full commercial relocation</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <Monitor className="text-white w-6 h-6" />
                  </div>
                  Specialist Business Services
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Monitor className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">IT & Server Relocation</p>
                    <p className="text-primary font-bold">Starting from £100</p>
                    <p className="text-sm text-slate-500 mt-1">Safe handling of tech</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Archive className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Crate Hire</p>
                    <p className="text-primary font-bold">£2 per crate / week</p>
                    <p className="text-sm text-slate-500 mt-1">Secure packing for files</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Users className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Weekend Relocation</p>
                    <p className="text-primary font-bold">+15% Surcharge</p>
                    <p className="text-sm text-slate-500 mt-1">Minimize business downtime</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <ShieldCheck className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Commercial Insurance</p>
                    <p className="text-primary font-bold">Included</p>
                    <p className="text-sm text-slate-500 mt-1">Full liability coverage</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <TrendingDown className="text-accent w-6 h-6" />
                  Business Move Optimization
                </h2>
                <p className="text-slate-300 mb-6">To ensure a smooth transition for your business at the best price:</p>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Plan Ahead:</span> Booking 4 weeks in advance can save up to 15% on commercial rates.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Asset Inventory:</span> A clear list of desks, chairs, and IT units ensures an accurate fixed-price quote.</p>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Need a formal quote for your business relocation?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Request Business Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const ManVanPricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Man & Van <span className="text-primary italic">Price Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Our Man & Van service is perfect for smaller moves and single items. Below is the 2026 Price Guide. Please note these are "starting from" prices for local moves.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Truck className="text-white w-6 h-6" />
                  </div>
                  Service Type & Starting Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Service Type</th>
                        <th className="py-4 font-bold text-slate-900">Starting Price (Est.)</th>
                        <th className="py-4 font-bold text-slate-900">Best For</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Small Item / Single Furniture</td>
                        <td className="py-4 text-primary font-bold">£35</td>
                        <td className="py-4 text-slate-600">Sofa, Fridge, or Desk only</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Part-Load / Small Van</td>
                        <td className="py-4 text-primary font-bold">£59</td>
                        <td className="py-4 text-slate-600">10-15 boxes or a student room</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">1 Bedroom Flat</td>
                        <td className="py-4 text-primary font-bold">£180</td>
                        <td className="py-4 text-slate-600">Full room contents, local move</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">2 Bedroom House</td>
                        <td className="py-4 text-primary font-bold">£350</td>
                        <td className="py-4 text-slate-600">Standard 2-bed inventory</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <Plus className="text-white w-6 h-6" />
                  </div>
                  Common Service Add-ons
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Package className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Packing Service</p>
                    <p className="text-primary font-bold">Starting from £150</p>
                    <p className="text-sm text-slate-500 mt-1">Includes boxes & tape</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Wrench className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Dismantle/Reassemble</p>
                    <p className="text-primary font-bold">Starting from £40</p>
                    <p className="text-sm text-slate-500 mt-1">Per item (Beds/Wardrobes)</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <Clock className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Wait-Time Fee</p>
                    <p className="text-primary font-bold">£60 per hour</p>
                    <p className="text-sm text-slate-500 mt-1">If you don't have keys yet</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <ArrowUp className="text-primary w-8 h-8 mb-4" />
                    <p className="font-bold text-slate-900">Stair Surcharge</p>
                    <p className="text-primary font-bold">£20–£40 per floor</p>
                    <p className="text-sm text-slate-500 mt-1">If no lift is available</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <TrendingDown className="text-accent w-6 h-6" />
                  How to get your exact price
                </h2>
                <p className="text-slate-300 mb-6">Since AnyVan uses dynamic pricing, the "starting from" price is for the most basic version of that move. To get your final figure:</p>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Inventory matters:</span> The price changes every time you add a box or a chair to the list.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Date matters:</span> Booking a Tuesday is usually 20% cheaper than a Friday or Saturday.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">The Price Match:</span> If you have a cheaper quote from a local "Man with a Van," AnyVan will usually match it if you show them the quote.</p>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Need a quick Man & Van quote?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Book Man & Van Now
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const PackingPricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Packing Service <span className="text-primary italic">Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                AnyVan typically offers packing as part of their "Premium" package or as an individual add-on. Because they charge based on the number of items and boxes, the price scales with the size of your home.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Package className="text-white w-6 h-6" />
                  </div>
                  Service Item & Estimated Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Service Item</th>
                        <th className="py-4 font-bold text-slate-900">Estimated Price</th>
                        <th className="py-4 font-bold text-slate-900">What's Included</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Per Box (Packing only)</td>
                        <td className="py-4 text-primary font-bold">£5.00</td>
                        <td className="py-4 text-slate-600">Labor only (you provide boxes)</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Per Box (Full Service)</td>
                        <td className="py-4 text-primary font-bold">£7.50 – £9.00</td>
                        <td className="py-4 text-slate-600">Labor + Box + Tape + Bubble wrap</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Unpacking Service</td>
                        <td className="py-4 text-primary font-bold">£4.00 per box</td>
                        <td className="py-4 text-slate-600">Placing items on flat surfaces</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Wardrobe Box Service</td>
                        <td className="py-4 text-primary font-bold">£15.00 – £20.00</td>
                        <td className="py-4 text-slate-600">Specialist tall boxes for hanging clothes</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <Home className="text-white w-6 h-6" />
                  </div>
                  Estimated Total Packing Costs (By Home Size)
                </h2>
                <p className="text-slate-600 mb-6">If you want a "Full Pack" where the team does everything, these are the typical total add-ons to your moving quote:</p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">1 Bedroom Flat</p>
                    <p className="text-primary font-bold text-xl">£150 – £250</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">2 Bedroom House</p>
                    <p className="text-primary font-bold text-xl">£280 – £450</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">3 Bedroom House</p>
                    <p className="text-primary font-bold text-xl">£450 – £700</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">4+ Bedroom House</p>
                    <p className="text-primary font-bold text-xl">£750 – £1,200+</p>
                  </div>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Plus className="text-white w-6 h-6" />
                  </div>
                  Specialist Packing Add-ons
                </h2>
                <ul className="space-y-4">
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Monitor className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">TV Packing</p>
                      <p className="text-slate-600"><span className="text-primary font-bold">£25 – £40</span> (includes specialist heavy-duty TV crate/box)</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <ShieldCheck className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Fragile Only Pack</p>
                      <p className="text-slate-600"><span className="text-primary font-bold">£100 – £200</span> (Kitchen glass, mirrors, and artwork only)</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Wrench className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Dismantle & Pack</p>
                      <p className="text-slate-600"><span className="text-primary font-bold">£45 – £80</span> per large item (e.g., packing a dismantled bed frame)</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <AlertCircle className="text-accent w-6 h-6" />
                  Important Notes for 2026
                </h2>
                <ul className="space-y-6">
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">The "Premium" Package:</span> If you select the "Premium" option on AnyVan, the packing service is usually bundled into one fixed price, which is often 30-40% cheaper than adding boxes individually.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Timeline:</span> For 3+ bedroom houses, AnyVan may send a team the day before the move to do the packing. Check your quote to see if it's a "Same Day" or "Two Day" service.</p>
                  </li>
                  <li className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    </div>
                    <p><span className="font-bold text-white">Insurance:</span> AnyVan’s standard insurance often only covers "breakages" if they did the packing. If you pack the boxes yourself and something breaks inside, they may not pay out.</p>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to create a "Packing Checklist" you can use to track your boxes on moving day?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Get a Packing Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const PianoPricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Piano Transport <span className="text-primary italic">Price Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Piano transport is a specialist service on AnyVan because of the extreme weight and delicacy of the instrument. They do not have a flat "price list," but they use a specialist surcharge system.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Music className="text-white w-6 h-6" />
                  </div>
                  Piano Type & Estimated Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Piano Type</th>
                        <th className="py-4 font-bold text-slate-900">Local Move (Under 15 miles)</th>
                        <th className="py-4 font-bold text-slate-900">Long Distance (50+ miles)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Digital / Electric Piano</td>
                        <td className="py-4 text-primary font-bold">£60 – £110</td>
                        <td className="py-4 text-primary font-bold">£120 – £180</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Standard Upright Piano</td>
                        <td className="py-4 text-primary font-bold">£160 – £280</td>
                        <td className="py-4 text-primary font-bold">£300 – £550</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Baby Grand Piano</td>
                        <td className="py-4 text-primary font-bold">£320 – £500</td>
                        <td className="py-4 text-primary font-bold">£550 – £850</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Grand / Concert Grand</td>
                        <td className="py-4 text-primary font-bold">£550 – £900+</td>
                        <td className="py-4 text-primary font-bold">Custom Quote Only</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <ArrowUp className="text-white w-6 h-6" />
                  </div>
                  Crucial Surcharges (The "Step" Price)
                </h2>
                <p className="text-slate-600 mb-6">Pianos are heavy (200kg–500kg+), so "access" is the biggest price driver. You will be charged extra for:</p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Ground Floor to Ground Floor</p>
                    <p className="text-primary font-bold">Included in the base price</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Flights of Stairs</p>
                    <p className="text-primary font-bold">£50 – £100 per flight</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Tight Turns/Internal Steps</p>
                    <p className="text-primary font-bold">£20 – £40 fee</p>
                    <p className="text-sm text-slate-500 mt-1">Even 2–3 steps inside a hallway</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Second Man Requirement</p>
                    <p className="text-primary font-bold">£60 – £100 extra</p>
                    <p className="text-sm text-slate-500 mt-1">Pianos (except digital) require at least 2 people</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <ExternalLink className="text-accent w-6 h-6" />
                  Copy & Paste: Details for your Piano Quote
                </h2>
                <p className="text-slate-300 mb-6">To get a fixed price that won't change on the day, paste this into the AnyVan "Special Instructions" box:</p>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 font-mono text-sm text-slate-300">
                  <p className="text-accent font-bold mb-2">Piano Specification:</p>
                  <ul className="space-y-1">
                    <li>• Type: [e.g., Upright / Baby Grand / Digital]</li>
                    <li>• Make/Model: [e.g., Yamaha U3]</li>
                    <li>• Pickup Access: [e.g., Ground floor, 2 external steps]</li>
                    <li>• Delivery Access: [e.g., 1st Floor, via wide staircase]</li>
                    <li>• Casters: [Yes/No] - (Do the wheels work?)</li>
                  </ul>
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-red-50 border border-red-100 flex gap-4 mb-12">
                <AlertCircle className="text-red-500 w-6 h-6 flex-shrink-0" />
                <p className="text-red-800 text-sm">
                  <span className="font-bold">Important Warning:</span> Standard AnyVan insurance often excludes pianos or has a very high "excess" unless you pay for Enhanced Insurance. Because a piano can be tuned for £100 but repaired for £2,000, I strongly recommend checking the "Enhanced Insurance" box during checkout (usually an extra £15 – £30).
                </p>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to check if your specific piano model requires a "specialist hoist" or if a standard two-man team can handle it?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Get a Piano Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const MotorcyclePricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Motorbike Transport <span className="text-primary italic">Price Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                AnyVan's motorcycle transport is popular because they use "empty space" in vans already traveling your route, which keeps the price low. However, because it is a vehicle, the price is higher than standard furniture.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Bike className="text-white w-6 h-6" />
                  </div>
                  Distance & Estimated Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Service Type</th>
                        <th className="py-4 font-bold text-slate-900">Distance</th>
                        <th className="py-4 font-bold text-slate-900">Estimated Price</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Local Move</td>
                        <td className="py-4 text-slate-600">Under 15 miles</td>
                        <td className="py-4 text-primary font-bold">£55 – £85</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Short Distance</td>
                        <td className="py-4 text-slate-600">15 – 50 miles</td>
                        <td className="py-4 text-primary font-bold">£80 – £140</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Medium Distance</td>
                        <td className="py-4 text-slate-600">50 – 150 miles</td>
                        <td className="py-4 text-primary font-bold">£160 – £280</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Long Distance</td>
                        <td className="py-4 text-slate-600">200+ miles</td>
                        <td className="py-4 text-primary font-bold">£300 – £500+</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <Plus className="text-white w-6 h-6" />
                  </div>
                  Specific Item Add-ons
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Heavy/Large Bikes</p>
                    <p className="text-primary font-bold">£40 – £70 extra</p>
                    <p className="text-sm text-slate-500 mt-1">Cruisers (Harleys) or large Touring bikes (Goldwings)</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Non-Runners</p>
                    <p className="text-primary font-bold">£30 – £50 surcharge</p>
                    <p className="text-sm text-slate-500 mt-1">If the bike doesn't roll or has a seized brake</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Next-Day Priority</p>
                    <p className="text-primary font-bold">+20% Price Increase</p>
                    <p className="text-sm text-slate-500 mt-1">Adding a specific time/date for delivery</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <ExternalLink className="text-accent w-6 h-6" />
                  Copy & Paste: Details for your Motorbike Quote
                </h2>
                <p className="text-slate-300 mb-6">To get the most accurate "Fixed Price," paste these details into the AnyVan quote box:</p>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 font-mono text-sm text-slate-300">
                  <p className="text-accent font-bold mb-2">Motorcycle Details:</p>
                  <ul className="space-y-1">
                    <li>• Make & Model: [e.g., Honda CB500 / BMW GS1250]</li>
                    <li>• Condition: [e.g., Running / Non-runner / Rolling chassis]</li>
                    <li>• Modifications: [e.g., Panniers attached / Extended forks]</li>
                    <li>• Accessories: [e.g., 2 boxes of spare parts / Spare tires]</li>
                    <li>• Collection Access: [e.g., Driveway / Secure Garage / Street]</li>
                  </ul>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <ShieldCheck className="text-white w-6 h-6" />
                  </div>
                  Important Things to Know for 2026
                </h2>
                <ul className="space-y-6">
                  <li className="flex gap-4 p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <ShieldCheck className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Standard Insurance</p>
                      <p className="text-slate-600">AnyVan typically includes £50,000 Goods in Transit cover. For high-value "classics" or "superbikes," consider Enhanced Insurance (approx. £15).</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Wrench className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Specialist Equipment</p>
                      <p className="text-slate-600">Most drivers use standard ramps and "soft straps." If your bike is extremely low or heavy, mention this so they send a van with a tail lift.</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Monitor className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Photos</p>
                      <p className="text-slate-600">Always take photos of the bike at the pickup point before it is loaded. This is your only proof if a scratch occurs during transit.</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to help you find the average weight of your specific bike model so you can tell the driver?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Get a Motorbike Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const StudentPricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Student Removals <span className="text-primary italic">Price Guide 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Student removals are typically AnyVan’s most affordable service because they involve smaller volumes (part-loads) and shorter distances. For 2026, they also offer specific student-only discounts.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <GraduationCap className="text-white w-6 h-6" />
                  </div>
                  Service Type & Estimated Prices
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Service Type</th>
                        <th className="py-4 font-bold text-slate-900">Estimated Price</th>
                        <th className="py-4 font-bold text-slate-900">Best For</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Small Part-Load</td>
                        <td className="py-4 text-primary font-bold">£26 – £45</td>
                        <td className="py-4 text-slate-600">5-10 boxes or a single suitcase</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Standard Room Move</td>
                        <td className="py-4 text-primary font-bold">£55 – £85</td>
                        <td className="py-4 text-slate-600">15 boxes + 1 small furniture item</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Full Studio/En-suite</td>
                        <td className="py-4 text-primary font-bold">£95 – £160</td>
                        <td className="py-4 text-slate-600">Bed, desk, chair, and all boxes</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">Inter-City Move</td>
                        <td className="py-4 text-primary font-bold">£180 – £350</td>
                        <td className="py-4 text-slate-600">Moving back home (e.g., London to Leeds)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <TrendingDown className="text-white w-6 h-6" />
                  </div>
                  How to get the "Student Price"
                </h2>
                <p className="text-slate-600 mb-6">AnyVan doesn’t apply student rates automatically. You must use a discount platform to lower the price:</p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">UNiDAYS / Student Beans</p>
                    <p className="text-primary font-bold text-xl">£10 Discount</p>
                    <p className="text-sm text-slate-500 mt-1">Get an instant discount code</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">TOTUM</p>
                    <p className="text-primary font-bold text-xl">£20 Discount</p>
                    <p className="text-sm text-slate-500 mt-1">Often higher for larger home removals</p>
                  </div>
                </div>
                <div className="mt-6 p-4 rounded-2xl bg-slate-50 border border-slate-100 flex gap-3 items-center">
                  <ExternalLink className="text-primary w-5 h-5" />
                  <p className="text-sm text-slate-600"><span className="font-bold">How to use:</span> Go to the "Students" link at the bottom of the AnyVan homepage before you start your quote.</p>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <TrendingDown className="text-white w-6 h-6" />
                  </div>
                  Cost-Saving Tips for Students
                </h2>
                <ul className="space-y-4">
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Truck className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">The "Shared Van" Trick</p>
                      <p className="text-slate-600 text-sm">AnyVan's lowest prices (from £26) come from "backloading." Your boxes share a van with someone else’s sofa. It’s much cheaper than a private van.</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Clock className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Mid-Week Moves</p>
                      <p className="text-slate-600 text-sm">Try to move on a Tuesday or Wednesday. Avoid the last weekend of June or the first weekend of September, as prices can double due to high demand.</p>
                    </div>
                  </li>
                  <li className="flex gap-4 p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <ArrowDown className="text-primary w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Ground Floor Drop-off</p>
                      <p className="text-slate-600 text-sm">If you can bring your boxes down to the kerb yourself, you can select the "No Help Needed" option to save roughly £30–£50.</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <ExternalLink className="text-accent w-6 h-6" />
                  Copy & Paste: Your Student Inventory List
                </h2>
                <p className="text-slate-300 mb-6">Use this when chatting with their support to ensure you get the best rate:</p>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 font-mono text-sm text-slate-300">
                  <p className="text-accent font-bold mb-2">Student Move Details:</p>
                  <ul className="space-y-1">
                    <li>• Status: Student (Verified via UNiDAYS)</li>
                    <li>• Inventory: [e.g., 10 Medium Boxes, 1 Suitcase, 1 Desk Lamp]</li>
                    <li>• Large Items: [e.g., 1 Office Chair - Disassembled]</li>
                    <li>• Route: [Pickup Postcode] to [Delivery Postcode]</li>
                    <li>• Access: [e.g., 3rd Floor with Lift / Ground Floor]</li>
                    <li>• Flexibility: [e.g., Happy to share van space with other customers]</li>
                  </ul>
                </div>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to find a discount code for you, or help you estimate how many boxes you'll need for a standard dorm room?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Get a Student Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const StoragePricingPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-8 md:p-12 shadow-xl border border-slate-100"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Storage Services <span className="text-primary italic">Price List 2026</span>
            </h1>
            
            <div className="prose prose-slate max-w-none">
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                AnyVan’s storage model is "door-to-door," meaning they collect your items, store them in a secure facility, and redeliver them when you’re ready. Unlike traditional self-storage, you don't usually visit the unit yourself.
              </p>

              <div className="bg-primary/5 rounded-3xl p-8 mb-12 border border-primary/10">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Box className="text-white w-6 h-6" />
                  </div>
                  Weekly Storage Rates (Est.)
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="py-4 font-bold text-slate-900">Unit Size</th>
                        <th className="py-4 font-bold text-slate-900">Weekly Price (Est.)</th>
                        <th className="py-4 font-bold text-slate-900">Capacity Example</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">35 sq ft</td>
                        <td className="py-4 text-primary font-bold">£24 – £35</td>
                        <td className="py-4 text-slate-600">1-bed flat / 30-40 boxes</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">70 sq ft</td>
                        <td className="py-4 text-primary font-bold">£48 – £70</td>
                        <td className="py-4 text-slate-600">2-bed flat / large furniture</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">100 sq ft</td>
                        <td className="py-4 text-primary font-bold">£72 – £105</td>
                        <td className="py-4 text-slate-600">3-bed house contents</td>
                      </tr>
                      <tr>
                        <td className="py-4 text-slate-700 font-medium">150 sq ft+</td>
                        <td className="py-4 text-primary font-bold">£96 – £140+</td>
                        <td className="py-4 text-slate-600">Large house / commercial stock</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="mt-4 text-sm text-slate-500 italic">Note: Prices vary by location. London (Battersea/Heathrow) is typically at the higher end, while Park Royal or regional hubs are cheaper.</p>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <AlertCircle className="text-white w-6 h-6" />
                  </div>
                  The "Hidden" Storage Costs
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Collection Fee</p>
                    <p className="text-primary font-bold">£150 – £300 (Est.)</p>
                    <p className="text-sm text-slate-500 mt-1">Initial move into storage (1-bed flat example)</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Redelivery Fee</p>
                    <p className="text-primary font-bold">Varies</p>
                    <p className="text-sm text-slate-500 mt-1">Removal fee to get your items back out</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Access Fee</p>
                    <p className="text-primary font-bold">£30 – £50 per visit</p>
                    <p className="text-sm text-slate-500 mt-1">Handling fee to access containerized units</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-slate-900">Insurance</p>
                    <p className="text-primary font-bold">£2 – £5 extra / week</p>
                    <p className="text-sm text-slate-500 mt-1">For high-value items in storage</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-8 text-white mb-12">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <ExternalLink className="text-accent w-6 h-6" />
                  Copy & Paste: Storage Request Details
                </h2>
                <p className="text-slate-300 mb-6">Paste this into their "Enquiry" box to get a specific price:</p>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 font-mono text-sm text-slate-300">
                  <p className="text-accent font-bold mb-2">Storage Requirement:</p>
                  <ul className="space-y-1">
                    <li>• Inventory Size: [e.g., 70 sq ft / contents of a 2-bed flat]</li>
                    <li>• Duration: [e.g., 4 weeks / Indefinite]</li>
                    <li>• Service Needed: [e.g., Collection + Storage + Redelivery]</li>
                    <li>• Items Needing Protection: [e.g., 1x Fabric Sofa (needs plastic wrap), 1x Mattress]</li>
                    <li>• Insurance Value: [Approx. total value of goods, e.g., £5,000]</li>
                  </ul>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <TrendingDown className="text-white w-6 h-6" />
                  </div>
                  Is it cheaper than Self-Storage?
                </h2>
                <div className="space-y-6">
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-green-600 flex items-center gap-2 mb-2">
                      <Plus className="w-4 h-4" /> Pros
                    </p>
                    <p className="text-slate-600 text-sm">AnyVan is usually 30% cheaper per week than companies like Big Yellow or Safestore because their warehouses are in cheaper, industrial areas. Plus, you don't have to hire your own van.</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm">
                    <p className="font-bold text-red-600 flex items-center gap-2 mb-2">
                      <Minus className="w-4 h-4" /> Cons
                    </p>
                    <p className="text-slate-600 text-sm">It is less flexible. If you need to get into your boxes every weekend, traditional self-storage is better. AnyVan storage is best for "set it and forget it" moves (e.g., moving house or traveling).</p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <p className="text-xl font-bold text-slate-900 mb-6">Would you like me to find the nearest AnyVan storage hub to your postcode?</p>
                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="bg-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary-light transition-all shadow-xl shadow-primary/20"
                >
                  Get a Storage Quote
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

const darkMapStyles = [
  { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
  { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
  { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
  {
    featureType: "administrative.locality",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "poi",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "poi.park",
    elementType: "geometry",
    stylers: [{ color: "#263c3f" }],
  },
  {
    featureType: "poi.park",
    elementType: "labels.text.fill",
    stylers: [{ color: "#6b9a76" }],
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#38414e" }],
  },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#212a37" }],
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#9ca5b3" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry",
    stylers: [{ color: "#746855" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry.stroke",
    stylers: [{ color: "#1f2835" }],
  },
  {
    featureType: "road.highway",
    elementType: "labels.text.fill",
    stylers: [{ color: "#f3d19c" }],
  },
  {
    featureType: "transit",
    elementType: "geometry",
    stylers: [{ color: "#2f3948" }],
  },
  {
    featureType: "transit.station",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#17263c" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.fill",
    stylers: [{ color: "#515c6d" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.stroke",
    stylers: [{ color: "#17263c" }],
  },
];

const InventoryCalculator = ({ onBack }: { onBack: () => void }) => {
  const [inventory, setInventory] = useState<Record<string, number>>({});
  const [pickupPostcode, setPickupPostcode] = useState('');
  const [deliveryPostcode, setDeliveryPostcode] = useState('');
  const [distance, setDistance] = useState(10); // Default mock distance
  const [isCalculating, setIsCalculating] = useState(false);
  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const [apiKey] = useState((import.meta as any).env.VITE_GOOGLE_MAPS_API_KEY || '');

  interface InventoryItem {
    id: string;
    name: string;
    volume: number;
    price: number;
    icon: React.ReactNode;
  }

  interface InventoryCategory {
    id: string;
    name: string;
    icon: React.ReactNode;
    items: InventoryItem[];
  }

  const categories: InventoryCategory[] = [
    {
      id: 'living',
      name: 'Living Room',
      icon: <Home className="w-5 h-5" />,
      items: [
        { id: 'sofa3', name: '3-Seater Sofa', volume: 50, price: 45, icon: <Sofa className="w-6 h-6" /> },
        { id: 'sofa2', name: '2-Seater Sofa', volume: 35, price: 35, icon: <Sofa className="w-6 h-6" /> },
        { id: 'armchair', name: 'Armchair', volume: 15, price: 15, icon: <Armchair className="w-6 h-6" /> },
        { id: 'coffee_table', name: 'Coffee Table', volume: 10, price: 10, icon: <Table className="w-6 h-6" /> },
        { id: 'tv', name: 'Large TV', volume: 5, price: 15, icon: <Monitor className="w-6 h-6" /> },
        { id: 'bookshelf', name: 'Bookshelf', volume: 20, price: 25, icon: <Library className="w-6 h-6" /> },
        { id: 'sideboard', name: 'Sideboard', volume: 30, price: 35, icon: <Archive className="w-6 h-6" /> },
      ]
    },
    {
      id: 'bedroom',
      name: 'Bedroom',
      icon: <Bed className="w-5 h-5" />,
      items: [
        { id: 'double_bed', name: 'Double Bed & Mattress', volume: 60, price: 55, icon: <Bed className="w-6 h-6" /> },
        { id: 'single_bed', name: 'Single Bed & Mattress', volume: 35, price: 35, icon: <Bed className="w-6 h-6" /> },
        { id: 'wardrobe', name: 'Large Wardrobe', volume: 50, price: 50, icon: <Archive className="w-6 h-6" /> },
        { id: 'drawers', name: 'Chest of Drawers', volume: 20, price: 20, icon: <Box className="w-6 h-6" /> },
        { id: 'bedside_table', name: 'Bedside Table', volume: 5, price: 10, icon: <Table className="w-6 h-6" /> },
        { id: 'mirror', name: 'Large Mirror', volume: 5, price: 15, icon: <Maximize className="w-6 h-6" /> },
        { id: 'rug', name: 'Large Rug', volume: 5, price: 10, icon: <Layers className="w-6 h-6" /> },
      ]
    },
    {
      id: 'kitchen',
      name: 'Kitchen',
      icon: <Utensils className="w-5 h-5" />,
      items: [
        { id: 'washing_machine', name: 'Washing Machine', volume: 20, price: 30, icon: <Waves className="w-6 h-6" /> },
        { id: 'fridge', name: 'Fridge Freezer (Tall)', volume: 35, price: 40, icon: <Snowflake className="w-6 h-6" /> },
        { id: 'dining_table', name: 'Dining Table', volume: 25, price: 25, icon: <Table className="w-6 h-6" /> },
        { id: 'dishwasher', name: 'Dishwasher', volume: 20, price: 30, icon: <Waves className="w-6 h-6" /> },
        { id: 'microwave', name: 'Microwave', volume: 3, price: 10, icon: <Box className="w-6 h-6" /> },
        { id: 'oven', name: 'Oven / Cooker', volume: 20, price: 35, icon: <Flame className="w-6 h-6" /> },
      ]
    },
    {
      id: 'general',
      name: 'General',
      icon: <Package className="w-5 h-5" />,
      items: [
        { id: 'box', name: 'Standard Removal Box', volume: 4, price: 5, icon: <Package className="w-6 h-6" /> },
        { id: 'suitcase', name: 'Suitcase / Bag', volume: 3, price: 3, icon: <Briefcase className="w-6 h-6" /> },
        { id: 'bicycle', name: 'Bicycle', volume: 15, price: 20, icon: <Bike className="w-6 h-6" /> },
        { id: 'desk', name: 'Office Desk', volume: 20, price: 25, icon: <Table className="w-6 h-6" /> },
        { id: 'office_chair', name: 'Office Chair', volume: 10, price: 15, icon: <UserCheck className="w-6 h-6" /> },
        { id: 'lamp', name: 'Floor Lamp', volume: 5, price: 10, icon: <Lightbulb className="w-6 h-6" /> },
        { id: 'plant', name: 'Large Plant', volume: 5, price: 10, icon: <Leaf className="w-6 h-6" /> },
      ]
    }
  ];

  const updateQuantity = (id: string, delta: number) => {
    setInventory(prev => ({
      ...prev,
      [id]: Math.max(0, (prev[id] || 0) + delta)
    }));
  };

  const totalVolume = Object.entries(inventory).reduce((acc: number, [id, qty]: [string, number]): number => {
    const item = categories.flatMap(c => c.items).find(i => i.id === id);
    const volume = item?.volume || 0;
    return acc + (volume * qty);
  }, 0);

  const itemsPrice = Object.entries(inventory).reduce((acc: number, [id, qty]: [string, number]): number => {
    const item = categories.flatMap(c => c.items).find(i => i.id === id);
    const price = item?.price || 0;
    return acc + (price * qty);
  }, 0);

  const getVanDetails = (volume: number) => {
    if (volume === 0) return { name: 'No items selected', base: 0, icon: <Truck className="w-6 h-6" /> };
    if (volume <= 150) return { name: 'Small Van', base: 40, icon: <Truck className="w-6 h-6" /> };
    if (volume <= 400) return { name: 'Medium Transit Van', base: 80, icon: <Truck className="w-8 h-8" /> };
    return { name: 'Luton Van', base: 150, icon: <Truck className="w-10 h-10" /> };
  };

  const calculateDistance = () => {
    if (!pickupPostcode || !deliveryPostcode) {
      alert('Please enter both pickup and delivery postcodes.');
      return;
    }
    
    if (!apiKey) {
      // Fallback if no API key is provided
      setIsCalculating(true);
      setTimeout(() => {
        setDistance(Math.floor(Math.random() * 45) + 5);
        setIsCalculating(false);
      }, 1500);
      return;
    }

    setIsCalculating(true);
    
    const directionsService = new google.maps.DirectionsService();
    directionsService.route(
      {
        origin: pickupPostcode,
        destination: deliveryPostcode,
        travelMode: google.maps.TravelMode.DRIVING,
        unitSystem: google.maps.UnitSystem.IMPERIAL,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          setDirections(result);
          const route = result.routes[0];
          if (route.legs[0].distance) {
            // Convert meters to miles
            const miles = route.legs[0].distance.value / 1609.34;
            setDistance(Math.round(miles));
          }
        } else {
          console.error(`error fetching directions ${result}`);
          alert('Could not calculate route. Please check your postcodes.');
        }
        setIsCalculating(false);
      }
    );
  };

  const van = getVanDetails(totalVolume);
  const distancePrice = distance * 1.5;
  const totalPrice = itemsPrice + van.base + distancePrice;

  const mapContainerStyle = {
    width: '100%',
    height: '300px',
    borderRadius: '24px',
    marginTop: '24px'
  };

  const center = {
    lat: 51.5074,
    lng: -0.1278
  };

  return (
    <LoadScript googleMapsApiKey={apiKey}>
      <div className="min-h-screen bg-slate-50">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onBack}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                <div className="absolute inset-0 bg-accent/20 rounded-full blur-sm" />
                <Truck className="text-primary w-8 h-8 relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl leading-none tracking-tight text-primary">
                  POMT <span className="text-accent">Logistics</span> LTD
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400 uppercase">Israel</span>
              </div>
            </div>
            <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-primary font-bold transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left: Inventory Selection */}
            <div className="lg:col-span-2 space-y-8">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-[40px] p-8 shadow-xl border border-slate-100"
              >
                <h1 className="text-3xl font-bold text-slate-900 mb-8">Inventory Calculator</h1>
                
                <div className="space-y-12">
                  {categories.map((category) => (
                    <div key={category.id}>
                      <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                          {category.icon}
                        </div>
                        {category.name}
                      </h2>
                      <div className="grid sm:grid-cols-2 gap-4">
                        {category.items.map((item) => (
                          <div key={item.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between group hover:bg-white hover:shadow-md transition-all">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-slate-400 group-hover:text-primary transition-colors">
                                {item.icon}
                              </div>
                              <div>
                                <p className="font-bold text-slate-900">{item.name}</p>
                                <p className="text-xs text-slate-500">{item.volume} ft³ • £{item.price}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <button 
                                onClick={() => updateQuantity(item.id, -1)}
                                className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-all"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span className="w-8 text-center font-bold text-slate-900">
                                {inventory[item.id] || 0}
                              </span>
                              <button 
                                onClick={() => updateQuantity(item.id, 1)}
                                className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-green-50 hover:text-green-600 hover:border-green-200 transition-all"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Right: Summary & Quote */}
            <div className="space-y-8">
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-slate-900 rounded-[40px] p-8 text-white sticky top-32 shadow-2xl"
              >
                <h2 className="text-2xl font-bold mb-8">Quote Summary</h2>
                
                <div className="space-y-6 mb-8">
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-slate-400">Total Volume</span>
                    <span className="font-bold text-xl">{totalVolume} ft³</span>
                  </div>
                  
                  <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-4 mb-2">
                      <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center text-white">
                        {van.icon}
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Recommended Van</p>
                        <p className="font-bold text-lg">{van.name}</p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-2 italic">Base Price: £{van.base}</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pickup Postcode</label>
                      <input 
                        type="text" 
                        placeholder="e.g. SW1A 1AA"
                        value={pickupPostcode}
                        onChange={(e) => setPickupPostcode(e.target.value.toUpperCase())}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:border-accent transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Delivery Postcode</label>
                      <input 
                        type="text" 
                        placeholder="e.g. M1 1AE"
                        value={deliveryPostcode}
                        onChange={(e) => setDeliveryPostcode(e.target.value.toUpperCase())}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:border-accent transition-all"
                      />
                    </div>
                    <button 
                      onClick={calculateDistance}
                      disabled={isCalculating}
                      className="w-full bg-white/10 hover:bg-white/20 text-white py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2"
                    >
                      {isCalculating ? (
                        <>
                          <Clock className="w-4 h-4 animate-spin" />
                          Calculating...
                        </>
                      ) : (
                        <>
                          <MapPin className="w-4 h-4" />
                          Calculate Distance
                        </>
                      )}
                    </button>
                    
                    {apiKey && directions && (
                      <div className="mt-6 rounded-2xl overflow-hidden border border-white/10 shadow-inner">
                        <GoogleMap
                          mapContainerStyle={mapContainerStyle}
                          center={center}
                          zoom={10}
                          options={{
                            styles: darkMapStyles,
                            disableDefaultUI: true,
                          }}
                        >
                          <DirectionsRenderer
                            directions={directions}
                            options={{
                              polylineOptions: {
                                strokeColor: '#F27D26',
                                strokeWeight: 5,
                              },
                              markerOptions: {
                                visible: false
                              }
                            }}
                          />
                        </GoogleMap>
                      </div>
                    )}
                  </div>

                  <div className="pt-6 border-t border-white/10 space-y-2">
                    <div className="flex justify-between text-slate-400">
                      <span>Items Total</span>
                      <span>£{itemsPrice}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Van Base Price</span>
                      <span>£{van.base}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Distance ({distance} mi)</span>
                      <span>£{distancePrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center pt-4">
                      <span className="text-xl font-bold">Total Est. Price</span>
                      <span className="text-3xl font-bold text-accent">£{totalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => { onBack(); setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100); }}
                  className="w-full bg-accent text-white py-4 rounded-2xl font-bold text-lg hover:bg-accent-light transition-all shadow-xl shadow-accent/20"
                >
                  Book This Move
                </button>
                <p className="text-[10px] text-slate-500 mt-4 text-center">
                  * Prices are estimates based on 2026 market rates. Final price may vary based on specific inventory and distance.
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
    </LoadScript>
  );
};

export default function App() {
  const [view, setView] = useState('home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  if (view === 'house-pricing') {
    return <HousePricingPage onBack={() => setView('home')} />;
  }
  if (view === 'office-pricing') {
    return <OfficePricingPage onBack={() => setView('home')} />;
  }
  if (view === 'man-van-pricing') {
    return <ManVanPricingPage onBack={() => setView('home')} />;
  }
  if (view === 'packing-pricing') {
    return <PackingPricingPage onBack={() => setView('home')} />;
  }
  if (view === 'piano-pricing') {
    return <PianoPricingPage onBack={() => setView('home')} />;
  }
  if (view === 'motorcycle-pricing') {
    return <MotorcyclePricingPage onBack={() => setView('home')} />;
  }
  if (view === 'student-pricing') {
    return <StudentPricingPage onBack={() => setView('home')} />;
  }
  if (view === 'storage-pricing') {
    return <StoragePricingPage onBack={() => setView('home')} />;
  }
  if (view === 'inventory-calculator') {
    return <InventoryCalculator onBack={() => setView('home')} />;
  }

  return (
    <div className="min-h-screen">
      <Navbar onNavigate={(v) => setView(v)} />
      <main>
        <Hero onNavigate={(v) => setView(v)} />
        <Partners />
        <RecentMoves />
        <About />
        <WhyChooseUs onNavigate={(v) => setView(v)} />
        <Services onNavigate={(v) => setView(v)} />
        <Stats />
        <YouTubeShowcase />
        <HowItWorks onNavigate={(v) => setView(v)} />
        <TrustedBrands />
        <Testimonials />
        <TrustedByFamilies />
        <ServiceAreas />
        <Trustpilot />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
